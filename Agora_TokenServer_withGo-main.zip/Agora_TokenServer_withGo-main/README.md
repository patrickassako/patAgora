# Agora_TokenServer_withGo
This code is for your Agora projects, it will help you to generate tokens for your app
